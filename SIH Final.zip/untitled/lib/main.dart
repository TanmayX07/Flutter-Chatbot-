
import 'package:flutter/material.dart';
import 'package:untitled/page1.dart';
import 'package:untitled/new_chat.dart';
import 'package:untitled/page2.dart';
//import 'package:untitled/HomeScreen.dart';


void main() => runApp(MaterialApp(
  initialRoute: '/page1',
  routes: {
    '/page1':(context)=> page1(),
    '/new_chat':(context)=> ChatScreen(),
  },
 ),
);

