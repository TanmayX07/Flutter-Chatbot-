import 'package:flutter/material.dart';

class page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('AICTE'),
        centerTitle: true,
        backgroundColor: Colors.orange[600],
        elevation: 0.0,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context,'/new_chat');
        },
        backgroundColor: Colors.white54,
        child: Image.network('https://cdn.iconscout.com/icon/free/png-128/double-quotation-2130775-1794817.png'),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(30.0, 40.0, 30.0, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: CircleAvatar(
                radius: 50.0,
                backgroundImage: NetworkImage('https://upload.wikimedia.org/wikipedia/en/e/eb/All_India_Council_for_Technical_Education_logo.png'),
              ),
            ),
            Divider(
              color: Colors.black,
              height: 60.0,
            ),
            Text(
              'ABOUT:',
              style: TextStyle(
                color: Colors.blueAccent,
                fontWeight: FontWeight.bold,
                fontSize: 18.0,
                letterSpacing: 1.5,
              ),
            ),
            SizedBox(height: 10.0),
            Text(
              'The All India Council for Technical Education (AICTE) is a statutory body, and a national-level council for technical education, under the Department of Higher Education.[6] Established in November 1945 first as an advisory body and later on in 1987 given statutory status by an Act of Parliament, AICTE is responsible for proper planning and coordinated development of the technical education and management education system in India.',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w400,
                fontSize: 18.0,
                letterSpacing: 1.3,
              ),
            ),

            SizedBox(height: 30.0),
            Row(
              children: <Widget>[
                Icon(
                  Icons.web,
                  color: Colors.grey[400],
                ),
                SizedBox(width: 10.0),
                Text(
                  'www.aicte-india.org',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 15.0,
                    letterSpacing: 1.0,
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}