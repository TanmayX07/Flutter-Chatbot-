import 'package:flutter/material.dart';

class page2 extends StatefulWidget {
  const page2({Key? key}) : super(key: key);
  @override
  State<page2> createState() => _page2State();
}

class _page2State extends State<page2> {
TextEditingController queryController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "AICTE Bot",
        ),
        backgroundColor: Colors.orange[600],
      ),
      body: Container(
         child: Column(
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Center(
              child: Container(
                padding: EdgeInsets.only(top: 15,bottom: 10),
                child: Text("Today, ${(DateTime(2022,3,14))}",style: TextStyle(
               fontSize: 20
              ),
                ),
              )
            ),
            Divider(
              height: 5.0,
              color: Colors.deepOrange,
            ),
            Container(
              child: ListTile(
                leading: IconButton(
                  icon: Icon(Icons.camera_alt,color: Colors.blueAccent,size: 35,), onPressed: () {  },
                ),
                title: Container(
                  height: 35,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Color.fromRGBO(220, 220, 220, 1)
                  ),
                  padding: EdgeInsets.only(left: 15),
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: "Enter A Message",
                      hintStyle: TextStyle(
                        color: Colors.black26
                      ),
                     ),),),
                trailing: IconButton(
                    icon: Icon( Icons.send,
                      size: 30.0,
                      color: Colors.blueAccent,
                    ),
                    onPressed: () {

                    }),
    ),
            ),
            SizedBox(
              height: 15.0,
            )
    ],
        ),


      ),
    );
  }
}



//body: Stack
// children: didget>l
// AnimatedList(
// key: _listkey,
// initialItenCount:
// _data. length,
// itemBuilder:
// (BuildContext context, int index, Animation animation) (
// return buildIten(_datalindexl,animation, index);
// // AnimatedList
// AlignC
// atignment: Alignment. bottomCenter.