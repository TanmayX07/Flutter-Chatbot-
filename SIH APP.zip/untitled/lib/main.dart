
import 'package:flutter/material.dart';
import 'package:untitled/page1.dart';
import 'package:untitled/page2.dart';


void main() => runApp(MaterialApp(
  initialRoute: '/page1',
  routes: {
    '/page1':(context)=> page1(),
    '/page2':(context)=> page2(),
  },
 ),
);

