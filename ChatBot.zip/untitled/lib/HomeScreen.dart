// import 'package:flutter/material.dart';
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({Key? key}) : super(key: key);
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   final GlobalKey<AnimatedListState>_listKey=GlobalKey();
//   TextEditingController queryController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey[300],
//       appBar: AppBar(
//         backgroundColor: Colors.blue,
//         centerTitle: true,
//         title: Text("AICTE BOT"),
//       ),
//       body: Stack(
//         children: <Widget>[
//           AnimatedList(
//             key:_listKey,
//             initialItemCount: _data.length ,
//             itemBuilder: (BuildContext context,int index,Animation animation)
//             {
//               return buildItem(_data[index], animation, index);
//             },
//           ),
//           Align(
//             alignment: Alignment.bottomCenter,
//             child: ColorFiltered(
//               colorFilter: ColorFilter.linearToSrgbGamma(),
//               child: Container(
//                 color: Colors.white,
//                 child: Padding,
//                 padding: EdgeInsets.only(left: 20, right: 20),
//                 child: TextField(
//                   decoration: InputDecoration(
//                     icon: Icon(
//                       Icons.message,
//                           color: Colors.blue,
//
//                     )
//                   ),
//                 )
//               ),
//             ),
//           )
//
//
//         ],
//       ),
//
//     );
//   }
// }
//
// Widget buildItem(String item, Animation animation, int index)
// {
//
// }
//
//
