
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/constants.dart';
import 'package:intl/intl.dart';
import 'package:bubble/bubble.dart';

class ChatScreen extends StatefulWidget {
  static String id = 'chat_screen';

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final messageTextController = TextEditingController();

  String messageText="";
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    getCurrentUser();
  }

  void getCurrentUser() async {


  }

  //
  // void getMessage() async{
  //   final messages = await _firestore.collection('messages').get();
  //   for (var message in messages.docs){
  //     print(message.data());
  //   }
  // }

  // void messagesStream() async {
  //   await for (var snapshot in _firestore.collection('messages').snapshots()) {
  //     for (var message in snapshot.docs) {
  //       print(message.data());
  //     }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Scaffold(
        backgroundColor: Colors.grey[500],
        appBar: AppBar(
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(CupertinoIcons.back),
            color: Colors.white,
          ),
          actions: <Widget>[
            IconButton(
                icon: Icon(Icons.logout),
                onPressed: () {

                  // messagesStream();

                }),
          ],
          title: Text('Chat Room'),
          backgroundColor: Colors.orange[600],
        ),
        body: Container(
          constraints: BoxConstraints.expand(),
          decoration: BoxDecoration(
              ),
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                MessageStream(),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border(
                          top: BorderSide(
                              color: Colors.white.withOpacity(0.2), width: 1.0),
                          right: BorderSide(
                              color: Colors.white.withOpacity(0.2), width: 1.0),
                          bottom: BorderSide(
                            color: Colors.white.withOpacity(0.2),
                            width: 1.0,
                          ),
                          left: BorderSide(
                              color: Colors.white.withOpacity(0.2), width: 1.0)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: TextFormField(
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please';
                              }
                              return null;
                            },

                            controller: messageTextController,
                            onChanged: (value) {
                              messageText = value;
                            },
                            decoration: kMessageTextFieldDecoration,
                            onFieldSubmitted: (value){


                            },
                          ),
                        ),
                        TextButton.icon(
                          label: Text(''),
                          onPressed: () {
                            print("Hi");

                            // print(DateTime.now().toString());
                          },
                          style: ButtonStyle(
                            overlayColor:
                            MaterialStateProperty.all(Colors.transparent),
                          ),
                          icon: Icon(
                            Icons.send,
                            size: 18,
                            color: Colors.white,
                          ),
                          // child: Text(
                          //   'Send',
                          //   style: kSendButtonTextStyle,
                          // ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MessageStream extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    List<MessageBubble> messageBubbles = [];
    final messageBubble = MessageBubble(
      sender: "messageSender",
      text: "messageText",
      isMe:  true,
      dateTime: "messageDateTime",
      currentTime: "messageDateTime.toString()",
    );
    messageBubbles.add(messageBubble);
    return Expanded(
      child: ListView(
        reverse: true,
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
        children: messageBubbles,
      ),
    );
  }
}

class MessageBubble extends StatelessWidget {
  MessageBubble(
      {required this.sender, required this.text, required this.isMe, required this.dateTime, required this.currentTime});

  final String sender;
  final String text;
  final bool isMe;
  final String dateTime;
  final String currentTime;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(1.0),
      child: Column(
        crossAxisAlignment:
        isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment:
              isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
              // children: [
              //   Text(
              //     '$sender',
              //     style: TextStyle(
              //       color: Colors.white,
              //       fontSize: 12,
              //       fontWeight: FontWeight.w500,
              //     ),
              //   ),
              //   Padding(
              //     padding: EdgeInsets.fromLTRB(18, 6, 2, 2),
              //     child: Text(
              //       '$currentTime',
              //       textAlign: TextAlign.right,
              //       style: TextStyle(
              //           fontSize: 10,
              //           color: Colors.white.withOpacity(0.8),
              //           fontStyle: FontStyle.italic),
              //     ),
              //   ),
              // ],
            ),
          ),
          Bubble(
            margin: isMe ? BubbleEdges.fromLTRB(80, 1, 0, 1) : BubbleEdges.fromLTRB(0, 1, 80, 1),
            color: isMe ? Color(0xFF348065) : Color(0xFF585f67),
            child: Padding(
              padding: const EdgeInsets.all(3.0),

              child: Column(
                crossAxisAlignment: isMe? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  Text(
                    '$sender',
                    style: TextStyle(
                        color: Colors.white,
                        // backgroundColor: Color(0xFF2A6551),
                        fontSize: 12,
                        fontWeight: FontWeight.w800
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 6,bottom: 6),
                    child: Text(
                      '$text',
                      textAlign: isMe ? TextAlign.right : TextAlign.left,
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Text(
                    '$currentTime',
                    style: TextStyle(
                        color: Colors.white,
                        fontStyle: FontStyle.italic,
                        fontSize: 9
                    ),
                  ),
                ],
              ),
            ),
            nip: isMe ? BubbleNip.rightTop : BubbleNip.leftTop,
          ),
        ],
      ),
    );
  }
}